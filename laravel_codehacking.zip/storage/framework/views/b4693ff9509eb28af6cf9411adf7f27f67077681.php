<style>
    .editor-img{
        height: 180px;
    }
    .thumb-img{
        height: 80px;
        width: 120px;
    }
    @media  screen and (max-width: 1366px) and (min-width: 993px) {
        .editor-img{
            height: 150px;
        }
        .thumb-img{
            height: 80px;
            width: 120px;
        }
    }
    @media  screen and (max-width: 992px) {
        .editor-img{
            height: auto;
        }
    }
</style>
<div class="sidebars-area">
    <div class="single-sidebar-widget editors-pick-widget">
        <h6 class="title">Editor’s Pick</h6>
        <div class="editors-pick-post">
            <?php if($editor): ?>
                <div class="feature-img-wrap relative">
                    <div class="feature-img relative editor-img">
                        <div class="overlay overlay-bg"></div>
                        <img class="img-fluid" src="<?php echo e($editor->photo ? $editor->photo->file : $editor->photoPlaceHolder()); ?>" alt="">
                    </div>
                    <ul class="tags">
                        <li><a href="<?php echo e(route('home.category', $editor->category->name)); ?>"><?php echo e($editor->category->name); ?></a></li>
                    </ul>
                </div>
                <div class="details">
                    <a href="<?php echo e(route('home.post',[$editor->category->name,$editor->slug])); ?>">
                        <h4 class="mt-20"><?php echo e($editor->title); ?></h4>
                    </a>
                    <ul class="meta">
                        <li><a href="#"><span class="lnr lnr-user"></span><?php echo e($editor->user->name); ?></a></li>
                        <li><a href="#"><span class="lnr lnr-calendar-full"></span><?php echo e($editor->created_at->format('d F, Y')); ?></a></li>
                    </ul>
                    <p class="excert">
                        <?php echo str_limit(strip_tags($editor->body), 120, ' <strong>.....</strong>'); ?>

                    </p>
                </div>
            <?php endif; ?>
            <?php if(!$editor_others->isEmpty()): ?>
                <?php $__currentLoopData = $editor_others; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $editor_other): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="post-lists">
                        <div class="single-post d-flex flex-row">
                            <div class="thumb">
                                <img class="thumb-img" src="<?php echo e($editor_other->photo ? $editor_other->photo->file : $editor_other->photoPlaceHolder()); ?>" alt="">
                            </div>
                            <div class="detail">
                                <a href="<?php echo e(route('home.post',[$editor_other->category->name,$editor_other->slug])); ?>"><h6><?php echo e($editor_other->title); ?></h6></a>
                                <ul class="meta">
                                    <li><a href="#"><span class="lnr lnr-calendar-full"></span><?php echo e($editor_other->created_at->format('d F, Y')); ?></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </div>

    
    <div class="single-sidebar-widget ads-widget">
        <img class="img-fluid" src="img/sidebar-ads.jpg" alt="">
    </div>

    <div class="single-sidebar-widget most-popular-widget">
        <h6 class="title">Most Popular</h6>
        <?php if(!$side_most_visits->isEmpty()): ?>
            <?php $__currentLoopData = $side_most_visits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $side_most_visit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="single-list flex-row d-flex">
                <div class="thumb">
                    <img class="thumb-img" src="<?php echo e($side_most_visit->photo ? $side_most_visit->photo->file : $side_most_visit->photoPlaceHolder()); ?>" alt="">
                </div>
                <div class="details">
                    <a href="<?php echo e(route('home.post',[$side_most_visit->category->name,$side_most_visit->slug])); ?>">
                        <h6><?php echo e($side_most_visit->title); ?></h6>
                    </a>
                    <ul class="meta">
                        <li><a href="#"><span class="lnr lnr-calendar-full"></span><?php echo e($side_most_visit->created_at->format('d F, Y')); ?></a></li>
                        <li><a href="#"><span class="lnr lnr-eye"></span><?php echo e($side_most_visit->visit_count); ?></a></li>
                    </ul>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>


    <div class="single-sidebar-widget social-network-widget">
        <h6 class="title">Social Networks</h6>
        <ul class="social-list">
            <li class="d-flex justify-content-between align-items-center fb">
                <div class="icons d-flex flex-row align-items-center">
                    <i class="fa fa-facebook" aria-hidden="true"></i>
                    <p>983 Likes</p>
                </div>
                <a href="#">Like our page</a>
            </li>
            <li class="d-flex justify-content-between align-items-center tw">
                <div class="icons d-flex flex-row align-items-center">
                    <i class="fa fa-twitter" aria-hidden="true"></i>
                    <p>983 Followers</p>
                </div>
                <a href="#">Follow Us</a>
            </li>
            <li class="d-flex justify-content-between align-items-center yt">
                <div class="icons d-flex flex-row align-items-center">
                    <i class="fa fa-youtube-play" aria-hidden="true"></i>
                    <p>983 Subscriber</p>
                </div>
                <a href="#">Subscribe</a>
            </li>
        </ul>
    </div>

    
    <div class="single-sidebar-widget ads-widget">
        <img class="img-fluid" src="img/sidebar-ads.jpg" alt="">
    </div>
</div>