<?php $__env->startSection('content'); ?>
    <div class="row" style="padding-top: 50px; padding-bottom: 100px">
        <style>
            .require:after{
                content:'*';
                color:red;
            }
        </style>
        <div class="col-sm-12">
            <div class="col-sm-12">
                <div class="col-sm-4">
                    <strong><h3>Edit Post</h3></strong>
                </div>
                <div class="col-sm-8">
                    <div class="panel-heading pull-right">
                        <a href="<?php echo e(route('admin.posts.index')); ?>" class="btn-primary btn-sm"><i class="fa fa-navicon"></i> All Posts</a>
                        <a href="<?php echo e(route('admin.posts.create')); ?>" class="btn-warning btn-sm"><i class="fa fa-plus"></i> Add New</a>
                    </div>
                </div>
            </div>
            <div class="col-sm-12">
                <div class="col-sm-4">
                    <img src="<?php echo e($post->photo ? $post->photo->file : $post->photoPlaceHolder()); ?>" alt="" class="img-responsive img-rounded">
                </div>
            </div>
            <div class="panel panel-default">
                <div class="panel-body">
                    <?php echo Form::model($post, ['method'=>'PATCH', 'action'=>['AdminPostsController@update', $post->id],'files'=>true]); ?>

                    <div class="form-group col-md-12 col-sm-10">
                        <?php echo Form::label('title', 'Title ',['class' => 'require']); ?>

                        <?php echo Form::text('title', null, ['class'=>'form-control','required']); ?>

                    </div>

                    <div class="form-group col-md-4 col-sm-10">
                        <?php echo Form::label('user_id', 'Author ',['class' => 'require']); ?>

                        <?php echo Form::select('user_id', ['' => 'Select Author'] + $authors, null, ['class'=>'form-control', 'id'=>'author','required']); ?>

                    </div>

                    <div class="form-group col-md-4 col-sm-10">
                        <?php echo Form::label('category_id', 'Category ',['class' => 'require']); ?>

                        <?php echo Form::select('category_id', ['' => 'Choose Categories'] + $categories, null, ['class'=>'form-control', 'id'=>'category','required']); ?>

                    </div>

                    <div class="form-group col-md-4 col-sm-10">
                        <?php echo Form::label('post_type', 'Post Type '); ?>

                        <?php echo Form::select('post_type', ['' => 'Select Type'] + $types, null, ['class'=>'form-control', 'id'=>'type']); ?>

                    </div>

                    <div class="form-group col-md-4 col-sm-10">
                        <?php echo Form::label('photo_id', 'Post Photo ',['class' => 'require']); ?>

                        <?php echo Form::file('photo_id', null, ['class'=>'form-control','required']); ?>

                    </div>

                    <div class="form-group col-md-8 col-sm-10">
                        <?php echo Form::label('photo_source', 'Photo Source ',['class' => 'require']); ?>

                        <?php echo Form::text('photo_source', null, ['class'=>'form-control','required']); ?>

                    </div>

                    <div class="form-group col-md-12 col-sm-12">
                        <?php echo Form::label('body', 'Body ',['class' => 'require']); ?>

                        <?php echo Form::textarea('body', null, ['class'=>'form-control']); ?>

                    </div>

                    <div class="form-group col-md-4 col-sm-10">
                        <?php echo Form::submit('Update Post', ['class'=>'btn btn-primary']); ?>

                    </div>
                    <?php echo Form::close(); ?>


                    <?php echo Form::open(['method'=>'DELETE', 'action'=>['AdminPostsController@destroy', $post->id]]); ?>

                    <div class="form-group col-md-4 col-sm-10">
                        <?php echo Form::submit('Delete Post', ['class'=>'btn btn-danger ']); ?>

                    </div>
                    <?php echo Form::close(); ?>


                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <?php echo $__env->make('includes.tinyeditor', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <script>
        $(document).ready(function() {
            $('#author').select2();
            $('#category').select2();
            $('#type').select2();
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>