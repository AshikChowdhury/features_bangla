<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Admin</title>
    <link rel="stylesheet" href="<?php echo e(mix('css/libs.css')); ?>" >

    <?php echo $__env->yieldContent('style'); ?>

</head>

<body id="admin-page">

<div id="wrapper">

    <!-- Navigation -->
    <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="/">Home</a>
        </div>
        <!-- /.navbar-header -->

        <ul class="nav navbar-top-links navbar-right">
            <!-- /.dropdown -->
            <li class="dropdown">
                <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                    <i class="fa fa-user fa-fw"></i> <?php echo e(Auth::user()->name); ?> <i class="fa fa-caret-down"></i>
                </a>
                <ul class="dropdown-menu dropdown-user">
                    <li><a href="#"><i class="fa fa-gear fa-fw"></i> Settings</a>
                    </li>
                    <li class="divider"></li>
                    <li><a href="<?php echo e(url('/logout')); ?>"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                    </li>
                </ul>
                <!-- /.dropdown-user -->
            </li>
            <!-- /.dropdown -->

        </ul>

        
        
        
        
        
        
        
        
        
        
        
        
        

        
        
        
        
        


        <div class="navbar-default sidebar" role="navigation">
            <div class="sidebar-nav navbar-collapse">
                <ul class="nav" id="side-menu">
                    <li class="sidebar-search">
                        <div class="input-group custom-search-form">
                            <input type="text" class="form-control" placeholder="Search...">
                            <span class="input-group-btn">
                                    <button class="btn btn-default" type="button">
                                        <i class="fa fa-search"></i>
                                    </button>
                                </span>
                        </div>
                        <!-- /input-group -->
                    </li>
                    <li class="<?php echo e(Request::is('/') ? 'active' : ''); ?>">
                        <a href="/admin"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
                    </li>

                    <li class="<?php echo e(Request::is('admin.users') ? 'active' : ''); ?>">
                        <a href="#"><i class="fa fa-wrench fa-fw"></i> System Setup<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li class="<?php echo e(Request::is('admin.users.index') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('admin.users.index')); ?>">Users</a>
                            </li>
                        </ul>
                        <!-- /.nav-second-level -->
                    </li>

                    <li>
                        <a href="#"><i class="fa fa-newspaper-o fa-fw"></i> Posts<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="<?php echo e(route('admin.posts.index')); ?>">Posts</a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('admin.types.index')); ?>">Post Types</a>
                            </li>
                        </ul>
                        <!-- /.nav-second-level -->
                    </li>
                    <li>
                        <a href="<?php echo e(route('admin.categories.index')); ?>"><i class="fa fa-bars fa-fw"></i> Categories</a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-camera-retro fa-fw"></i> Media<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="<?php echo e(route('admin.media.index')); ?>">All Media</a>
                            </li>

                            <li>
                                <a href="<?php echo e(route('admin.media.create')); ?>">Upload Media</a>
                            </li>

                        </ul>
                        <!-- /.nav-second-level -->
                    </li>
                    
                        
                        
                            
                                
                            
                            
                                
                            
                            
                                
                            
                            
                                
                            
                            
                                
                            
                            
                                
                            
                        
                        
                    
                    
                        
                        
                            
                                
                            
                            
                                
                            
                            
                                
                                
                                    
                                        
                                    
                                    
                                        
                                    
                                    
                                        
                                    
                                    
                                        
                                    
                                
                                
                            
                        
                        
                    
                    
                        
                        
                            
                                
                            
                            
                                
                            
                        
                        
                    
                </ul>
            </div>
            <!-- /.sidebar-collapse -->
        </div>
        <!-- /.navbar-static-side -->
    </nav>


    
        
            
                
                    
                

                
                    
                    
                        
                            
                        

                        
                            
                        

                    
                    
                

            

        

    

</div>


<!-- Page Content -->
<div id="page-wrapper">
    <div class="container-fluid">
    

    <?php echo $__env->yieldContent('content'); ?>
    <!-- /.col-lg-12 -->
    

    <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</div>
<!-- /#page-wrapper -->

<!-- /#wrapper -->
<script src="<?php echo e(mix('js/libs.js')); ?>"></script>

<?php echo $__env->yieldContent('script'); ?>

</body>

</html>
