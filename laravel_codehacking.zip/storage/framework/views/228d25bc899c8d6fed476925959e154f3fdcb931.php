<?php $__env->startSection('content'); ?>
    <div class="row" style="padding-top: 50px; padding-bottom: 50px">
        <style>
            .error{
                color: red;
            }
            .require:after{
                content:'*';
                color:red;
            }
        </style>
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4><strong>Edit User</strong></h4>
                </div>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="col-lg-2">
                                <img src="<?php echo e($user->photo ? $user->photo->file : '/images/400x400.png'); ?>" alt="" class="img-responsive img-rounded">
                            </div>
                            <div class="col-lg-10">
                                <?php echo Form::model($user,['method'=>'PATCH', 'action'=>['AdminUsersController@update', $user->id],'files'=>true,'id'=>'UserForm']); ?>

                                <div class="form-group col-lg-6">
                                    <?php echo Form::label('name', 'Name ', ['class' => 'require']); ?>

                                    <?php echo Form::text('name', null, ['class'=>'form-control','id'=>'name','name'=>'name','placeholder'=>'Full Name']); ?>

                                </div>

                                <div class="form-group col-lg-6">
                                    <?php echo Form::label('email', 'Email ',['class' => 'require']); ?>

                                    <?php echo Form::email('email', null, ['class'=>'form-control','id'=>'email','name'=>'email','placeholder'=>'Email']); ?>

                                </div>
                                <div class="form-group col-lg-6">
                                    <?php echo Form::label('password', 'Password '); ?>

                                    <?php echo Form::password('password', ['class'=>'form-control', 'id'=>'password', 'name'=>'password','placeholder'=>'Password']); ?>

                                </div>
                                <div class="form-group col-lg-6">
                                    <?php echo Form::label('', 'Confirm Password '); ?>

                                    <?php echo Form::password('', ['class'=>'form-control','id'=>'confirm_password','name'=>'confirm_password','placeholder'=>'Same Password']); ?>

                                </div>
                                <div class="form-group col-lg-6">
                                    <?php echo Form::label('is_active', 'Status ', ['class' => 'require']); ?>

                                    <?php echo Form::select('is_active', [1=>'Active',0=>'Inactive'], null, ['class'=>'form-control','id'=>'status']); ?>

                                </div>
                                <div class="form-group col-lg-6">
                                    <?php echo Form::label('role_id', 'Role ', ['class' => 'require']); ?>

                                    <?php echo Form::select('role_id', ['' => 'Choose Options'] + $roles , null, ['class'=>'form-control','id'=>'role']); ?>

                                </div>
                                <div class="form-group col-lg-6">
                                    <?php echo Form::label('fb_link', 'Facebook Profile ', ['class' => 'require']); ?>

                                    <?php echo Form::text('fb_link', null, ['class'=>'form-control','id'=>'fb_link','name'=>'fb_link','placeholder'=>'https://www.facebook.com/xyz']); ?>

                                </div>
                                <div class="form-group col-lg-10">
                                    <?php echo Form::label('photo_id', 'User Photo'); ?>

                                    <?php echo Form::file('photo_id', null, ['class'=>'form-control']); ?>

                                </div>
                                <div class="form-group col-lg-3">
                                    <?php echo Form::submit('Update User', ['class'=>'btn btn-primary']); ?>

                                </div>
                                <?php echo Form::close(); ?>


                                <?php echo Form::open(['method'=>'DELETE', 'action'=>['AdminUsersController@destroy', $user->id]]); ?>

                                <div class="form-group col-lg-2">
                                    <?php echo Form::submit('Delete User', ['class'=>'btn btn-danger']); ?>

                                </div>
                                <?php echo Form::close(); ?>


                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function() {
            // validate signup form on keyup and submit
            $("#UserForm").validate({
                rules: {
                    name: "required",
                    password: {
                        minlength: 4
                    },
                    confirm_password: {
                        minlength: 4,
                        equalTo: "#password"
                    },
                    email: {
                        required: true,
                        email: true
                    },
                    status: "required",
                    role: "required"
                },
                messages: {
                    name: "Please enter your full name",

                    password: {
                        required: "Please provide a password",
                        minlength: "Your password must be at least 4 characters long"
                    },
                    confirm_password: {
                        required: "Please provide a password",
                        minlength: "Your password must be at least 4 characters long",
                        equalTo: "Please enter the same password"
                    },
                    email: "Please enter a valid email address",
                    status: "Please select status",
                    role: "Please select role"
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>